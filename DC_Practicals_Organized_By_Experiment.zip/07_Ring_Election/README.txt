Ring election
=============

Files in this folder:
- ring_election.py: Python program
- ring_nodes_15.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 ring_election.py ring_nodes_15.csv

Use the exact CSV filename and column names specified by your assigned practical chit.
