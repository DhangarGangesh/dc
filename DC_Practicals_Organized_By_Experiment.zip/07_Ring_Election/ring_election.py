import csv
import sys

csv_file = sys.argv[1] if len(sys.argv) > 1 else "ring_nodes_15.csv"
nodes = {}

with open(csv_file, newline="") as file:
    for row in csv.DictReader(file):
        node_id = int(row["node_id"])
        nodes[node_id] = {
            "next": int(row["next_node_id"]),
            "active": row["is_active"].strip().upper() == "TRUE"
        }

if not nodes:
    raise ValueError("No nodes found in CSV")

start = min(nodes)
current = start
visited = set()
active_nodes = []

print("Coordinator failure detected.")
print("Election token circulation:")

while current not in visited:
    if current not in nodes:
        raise ValueError("Ring points to missing node " + str(current))

    visited.add(current)
    if nodes[current]["active"]:
        print("Token reached active Node", current)
        active_nodes.append(current)
    else:
        print("Node", current, "is inactive; skipped")

    current = nodes[current]["next"]

if current != start:
    print("Warning: traversal closed at a node other than the start")

if not active_nodes:
    print("No active node can become coordinator.")
else:
    new_coordinator = max(active_nodes)
    print("\nActive nodes:", active_nodes)
    print("New Coordinator:", new_coordinator)
    print("\nCOORDINATOR announcement:")
    for node in active_nodes:
        print("Node", node, "recognises Node",
              new_coordinator, "as coordinator")
