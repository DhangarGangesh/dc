Vector clocks
=============

Files in this folder:
- vector_clock.py: Python program
- vector_events_6.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 vector_clock.py vector_events_6.csv

Use the exact CSV filename and column names specified by your assigned practical chit.
