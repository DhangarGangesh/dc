import csv
import sys
from collections import defaultdict, deque
from itertools import combinations

csv_file = sys.argv[1] if len(sys.argv) > 1 else "vector_events_6.csv"

processes = ["P1", "P2", "P3"]
index = {p: i for i, p in enumerate(processes)}
clocks = {p: [0, 0, 0] for p in processes}
messages = defaultdict(deque)
event_vectors = []

with open(csv_file, newline="") as file:
    for row in csv.DictReader(file):
        event_id = row["event_id"]
        process = row["process_id"].strip()
        action = row["event_action"].strip().upper()
        target = row["target_process"].strip()
        i = index[process]

        if action == "INTERNAL":
            clocks[process][i] += 1

        elif action == "SEND":
            clocks[process][i] += 1
            messages[(process, target)].append(clocks[process].copy())

        elif action == "RECEIVE":
            key = (target, process)  # target is the sender
            if messages[key]:
                received = messages[key].popleft()
                clocks[process] = [
                    max(local, incoming)
                    for local, incoming in zip(clocks[process], received)
                ]
            else:
                print("WARNING: matching message not found")
            clocks[process][i] += 1

        else:
            raise ValueError("Unknown action: " + action)

        current = clocks[process].copy()
        print(event_id, process, action, "Vector =", current)
        event_vectors.append((event_id, current))

def happens_before(a, b):
    return (all(x <= y for x, y in zip(a, b))
            and any(x < y for x, y in zip(a, b)))

print("\n===== CAUSALITY / CONCURRENCY =====")
for (id1, v1), (id2, v2) in combinations(event_vectors, 2):
    if happens_before(v1, v2):
        print(id1, "<", id2, ": Causally preceding")
    elif happens_before(v2, v1):
        print(id2, "<", id1, ": Causally preceding")
    else:
        print(id1, "||", id2, ": Concurrent")
