import csv
import sys

csv_file = sys.argv[1] if len(sys.argv) > 1 else "node_clocks_3.csv"
valid_nodes = []

with open(csv_file, newline="") as file:
    for row in csv.DictReader(file):
        node = row["node_id"]
        clock_time = float(row["clock_time_sec"])
        faulty = row["is_faulty"].strip().upper() == "TRUE"

        print(node, "Clock:", clock_time)
        if faulty:
            print(node, "is faulty; excluded from average")
        else:
            valid_nodes.append((node, clock_time))

if not valid_nodes:
    raise ValueError("No valid clocks available")

average = sum(value for _, value in valid_nodes) / len(valid_nodes)
print("\nAverage accepted clock time:", average, "seconds")
print("\n===== CLOCK ADJUSTMENTS =====")

for node, value in valid_nodes:
    adjustment = average - value
    print(node, "Adjustment:", adjustment, "seconds")
    if adjustment > 0:
        print("Move clock forward")
    elif adjustment < 0:
        print("Move clock backward")
    else:
        print("Already synchronised")

print("\nSynchronisation calculation completed")
