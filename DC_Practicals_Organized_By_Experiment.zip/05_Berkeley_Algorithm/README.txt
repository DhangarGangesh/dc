Berkeley clock synchronisation
==============================

Files in this folder:
- berkeley.py: Python program
- node_clocks_3.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 berkeley.py node_clocks_3.csv

Use the exact CSV filename and column names specified by your assigned practical chit.
