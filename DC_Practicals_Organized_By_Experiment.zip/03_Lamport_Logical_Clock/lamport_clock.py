import csv
import sys
from collections import defaultdict, deque

csv_file = sys.argv[1] if len(sys.argv) > 1 else "events_7.csv"
clock = {}
messages = defaultdict(deque)
records = []

with open(csv_file, newline="") as file:
    for row in csv.DictReader(file):
        event_id = row["event_id"]
        process = row["process_id"]
        event_type = row["event_type"].strip().upper()
        peer = row["message_to"].strip()

        if process not in clock:
            clock[process] = int(row["initial_clock"])

        if event_type == "INTERNAL":
            clock[process] += 1

        elif event_type == "SEND":
            clock[process] += 1
            messages[(process, peer)].append(clock[process])
            print(f"{process} sends to {peer} at L={clock[process]}")

        elif event_type == "RECEIVE":
            key = (peer, process)  # peer is the sender
            if messages[key]:
                received_time = messages[key].popleft()
                clock[process] = max(clock[process], received_time) + 1
            else:
                print("WARNING: matching send timestamp not found")
                clock[process] += 1

        else:
            raise ValueError("Unknown event type: " + event_type)

        print(event_id, process, event_type, "Logical clock =", clock[process])
        records.append((event_id, process, clock[process]))

# Deterministic total display order; tie-break only resolves equal timestamps.
records.sort(key=lambda item: (item[2], item[1], item[0]))

print("\n===== TOTAL DISPLAY ORDER =====")
for event_id, process, timestamp in records:
    print(event_id, "->", process, "->", timestamp)
