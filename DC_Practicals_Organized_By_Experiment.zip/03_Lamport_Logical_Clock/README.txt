Lamport logical clock
=====================

Files in this folder:
- lamport_clock.py: Python program
- events_7.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 lamport_clock.py events_7.csv

Use the exact CSV filename and column names specified by your assigned practical chit.
