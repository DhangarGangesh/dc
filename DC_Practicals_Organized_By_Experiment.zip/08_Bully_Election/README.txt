Bully election
==============

Files in this folder:
- bully_election.py: Python program
- bully_cluster_2.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 bully_election.py bully_cluster_2.csv

Use the exact CSV filename and column names specified by your assigned practical chit.
