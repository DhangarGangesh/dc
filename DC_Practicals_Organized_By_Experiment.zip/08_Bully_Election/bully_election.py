import csv
import sys

csv_file = sys.argv[1] if len(sys.argv) > 1 else "bully_cluster_2.csv"
nodes = {}

with open(csv_file, newline="") as file:
    for row in csv.DictReader(file):
        node_id = int(row["node_id"])
        nodes[node_id] = {
            "alive": row["is_alive"].strip().upper() == "TRUE",
            "coordinator": row["is_current_coordinator"].strip().upper() == "TRUE"
        }

alive = sorted(n for n, data in nodes.items() if data["alive"])
if not alive:
    print("No active processes. Election cannot proceed.")
    raise SystemExit

old = [n for n, data in nodes.items() if data["coordinator"]]
if old:
    print("Previous coordinator:", old[0])
    if not nodes[old[0]]["alive"]:
        print("Coordinator", old[0], "has failed.")

# Select a live initiator for this simulation.
initiator = 2 if 2 in alive else alive[0]
print("\nNode", initiator, "starts the election.")

# Initiator sends ELECTION to all higher IDs.
higher_alive = [n for n in alive if n > initiator]
for n in range(initiator + 1, max(nodes) + 1):
    if n in nodes:
        print("ELECTION sent to Node", n)
        if nodes[n]["alive"]:
            print("Node", n, "replies: OK")

if not higher_alive:
    winner = initiator
else:
    # Higher responders take over the election in turn.
    for candidate in higher_alive:
        print("\nNode", candidate, "continues the election.")
        higher_than_candidate = [n for n in alive if n > candidate]
        for n in range(candidate + 1, max(nodes) + 1):
            if n in nodes:
                print("ELECTION sent to Node", n)
                if nodes[n]["alive"]:
                    print("Node", n, "replies: OK")
    winner = max(alive)

print("\n===== NEW COORDINATOR =====")
print("Node", winner, "is elected as Coordinator.")
print("COORDINATOR message broadcast:")
for n in alive:
    print("Node", n, "recognises Node", winner, "as Coordinator.")
