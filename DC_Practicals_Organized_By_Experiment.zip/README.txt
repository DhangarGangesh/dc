DISTRIBUTED COMPUTING PRACTICALS - ORGANIZED ZIP
================================================

This ZIP contains 10 separate experiment folders. Each folder contains its Python code, a matching sample CSV file, and a short README with the run command.

Ubuntu basics:
1. Extract: unzip DC_Practicals_Organized_By_Experiment.zip
2. Open a folder, for example: cd 01_RPC_RMI
3. Run: python3 rpc_rmi.py rpc_calls_1.csv

For load balancing, run with either rr (Round Robin) or lc (Least Connections).

IMPORTANT: Sample CSV files are examples. Your assigned chit may specify a different filename and/or columns. Follow the chit exactly and pass that filename to the Python script.

The MPI practical in this pack is a Python-thread-based Scatter/Gather simulation, not execution using a real MPI runtime.
