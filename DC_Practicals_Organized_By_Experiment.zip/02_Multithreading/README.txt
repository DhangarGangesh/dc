Multithreading
==============

Files in this folder:
- multithreading.py: Python program
- tasks_4.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 multithreading.py tasks_4.csv

Use the exact CSV filename and column names specified by your assigned practical chit.
