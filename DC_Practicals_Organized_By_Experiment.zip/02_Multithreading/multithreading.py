import csv
import threading
import time
import sys

lock = threading.Lock()
completed_tasks = []

def process_task(task):
    task_id = task["task_id"]
    worker = task["thread_name"]
    burst = int(task["burst_ms"])

    print(f"\n[{worker}] Started {task_id}")
    time.sleep(burst / 1000)  # Simulate work outside critical section

    with lock:
        print(f"[{worker}] Lock acquired")
        task["status"] = "COMPLETED"
        completed_tasks.append(task_id)
        print(f"[{worker}] Completed {task_id}")
        print(f"[{worker}] Lock released")

csv_file = sys.argv[1] if len(sys.argv) > 1 else "tasks_4.csv"

with open(csv_file, newline="") as file:
    tasks = list(csv.DictReader(file))

threads = []
for task in tasks:
    thread = threading.Thread(
        target=process_task,
        args=(task,),
        name=task["thread_name"]
    )
    threads.append(thread)
    thread.start()

for thread in threads:
    thread.join()

print("\n===== FINAL TASK STATUS =====")
for task in tasks:
    print(task["task_id"], ":", task["status"])

print("Completed tasks:", completed_tasks)
