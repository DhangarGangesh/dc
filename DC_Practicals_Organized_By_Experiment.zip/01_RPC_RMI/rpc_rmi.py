import csv
import sys

def processData(value):
    return value * 2

# Method name -> server-side function
METHODS = {
    "processData": processData
}

csv_file = sys.argv[1] if len(sys.argv) > 1 else "rpc_calls_1.csv"

with open(csv_file, newline="") as file:
    reader = csv.DictReader(file)

    for row in reader:
        call_id = row["call_id"]
        client = row["client_name"]
        method = row["method_name"]
        parameter = int(row["param_value"])

        # Marshalling: pack method and arguments into a request
        request = {
            "call_id": call_id,
            "method": method,
            "parameter": parameter
        }

        print("\n[DISPATCH]")
        print("Call ID:", call_id)
        print(client, "invoking", method)

        print("[SERVER EXECUTION]")
        if request["method"] in METHODS:
            result = METHODS[request["method"]](request["parameter"])
        else:
            result = "Method not found"

        print("[RETURN]")
        print("Result:", result)
        print("-" * 30)
