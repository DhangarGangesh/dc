RPC/RMI
=======

Files in this folder:
- rpc_rmi.py: Python program
- rpc_calls_1.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 rpc_rmi.py rpc_calls_1.csv

Use the exact CSV filename and column names specified by your assigned practical chit.
