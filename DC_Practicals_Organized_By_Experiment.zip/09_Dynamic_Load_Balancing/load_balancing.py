import csv
import sys

csv_file = sys.argv[1] if len(sys.argv) > 1 else "workload_13.csv"
mode = sys.argv[2].lower() if len(sys.argv) > 2 else "rr"

workers = ["Worker_1", "Worker_2", "Worker_3"]
job_count = {w: 0 for w in workers}
total_compute = {w: 0 for w in workers}

with open(csv_file, newline="") as file:
    jobs = list(csv.DictReader(file))

print("Scheduling mode:", "Round Robin" if mode == "rr" else "Least Connections")

for i, job in enumerate(jobs):
    if mode == "rr":
        worker = workers[i % len(workers)]
    elif mode == "lc":
        # Least Connections: choose worker with fewest assigned jobs.
        worker = min(workers, key=lambda w: (job_count[w], workers.index(w)))
    else:
        raise ValueError("Mode must be rr (Round Robin) or lc (Least Connections)")

    job["assigned_worker"] = worker
    job["status"] = "ASSIGNED"
    compute = int(job["compute_units"])
    job_count[worker] += 1
    total_compute[worker] += compute

    print(job["job_id"], "->", worker,
          "| Compute units:", compute)

print("\n===== WORKER LOAD SUMMARY =====")
for worker in workers:
    print(worker, "| Jobs:", job_count[worker],
          "| Total compute units:", total_compute[worker])

print("\nAll jobs allocated successfully.")
