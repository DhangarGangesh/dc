Dynamic load balancing
======================

Files in this folder:
- load_balancing.py: Python program
- workload_13.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 load_balancing.py workload_13.csv

Use the exact CSV filename and column names specified by your assigned practical chit.

Round Robin:
python3 load_balancing.py workload_13.csv rr

Least Connections:
python3 load_balancing.py workload_13.csv lc
