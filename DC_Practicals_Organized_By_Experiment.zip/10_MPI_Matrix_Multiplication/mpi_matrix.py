import csv
import sys
from concurrent.futures import ThreadPoolExecutor

def calculate_row(task):
    row_id, row, rows_of_a = task
    print("Worker processing:", row_id)

    # For A x A-transpose, each column of A-transpose
    # is a row of A.
    result = []
    for row_of_a in rows_of_a:
        dot = sum(x * y for x, y in zip(row, row_of_a))
        result.append(dot)

    print("Worker completed:", row_id)
    return row_id, result

csv_file = sys.argv[1] if len(sys.argv) > 1 else "matrix_38.csv"
matrix = []
row_ids = []

with open(csv_file, newline="") as file:
    for row in csv.DictReader(file):
        row_ids.append(row["row_id"])
        matrix.append([
            int(row["col_0"]),
            int(row["col_1"]),
            int(row["col_2"]),
            int(row["col_3"])
        ])

if not matrix or any(len(row) != 4 for row in matrix):
    raise ValueError("Expected a non-empty matrix with four columns")

print("===== MASTER: SCATTER =====")
tasks = []
for row_id, row in zip(row_ids, matrix):
    print("Sending", row_id, "to a worker")
    tasks.append((row_id, row, matrix))

print("\n===== WORKERS: COMPUTE =====")
with ThreadPoolExecutor(max_workers=min(4, len(tasks))) as executor:
    results = list(executor.map(calculate_row, tasks))

print("\n===== MASTER: GATHER =====")
results.sort(key=lambda item: row_ids.index(item[0]))

final_matrix = []
for row_id, result in results:
    print(row_id, ":", result)
    final_matrix.append(result)

print("\n===== FINAL A x A-TRANSPOSE =====")
for row in final_matrix:
    print(row)

print("Matrix multiplication completed.")
