MPI-style matrix multiplication simulation
==========================================

Files in this folder:
- mpi_matrix.py: Python program
- matrix_38.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 mpi_matrix.py matrix_38.csv

Use the exact CSV filename and column names specified by your assigned practical chit.
