import csv
import sys

csv_file = sys.argv[1] if len(sys.argv) > 1 else "cristian_clocks_8.csv"

with open(csv_file, newline="") as file:
    for row in csv.DictReader(file):
        client = row["client_id"]
        t0 = float(row["t0_send_ms"])
        server_time = float(row["t_server_ms"])
        t1 = float(row["t1_recv_ms"])

        rtt = t1 - t0
        estimated_server_time = server_time + (rtt / 2)
        offset = estimated_server_time - t1

        print("\nClient:", client)
        print("RTT:", rtt, "ms")
        print("Estimated server time at receipt:",
              estimated_server_time, "ms")
        print("Clock offset:", offset, "ms")

        if offset > 0:
            print("Client clock is behind by", offset, "ms")
        elif offset < 0:
            print("Client clock is ahead by", abs(offset), "ms")
        else:
            print("Client clock is synchronised")

        print("-" * 35)
