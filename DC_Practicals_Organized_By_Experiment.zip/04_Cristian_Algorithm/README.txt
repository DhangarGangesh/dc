Cristian clock synchronisation
==============================

Files in this folder:
- cristian.py: Python program
- cristian_clocks_8.csv: Sample CSV input

Run from this folder in Ubuntu:
python3 cristian.py cristian_clocks_8.csv

Use the exact CSV filename and column names specified by your assigned practical chit.
